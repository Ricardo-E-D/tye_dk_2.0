using System;
using System.Collections;
using System.Data;
using MySql.Data.MySqlClient;

namespace tye
{
	public class Tests : System.Web.UI.Page
	{
		private string strName;
		protected int intTestId;
		protected int intProgramId;
		protected double dblSeconds;
		protected DateTime datStarttime = Convert.ToDateTime("01-01-2004 01:01:01");
		protected int intScore;
		protected int intHighScore;
		protected bool blnHighScore = false;
		protected int intRequirement;
		protected bool blnCompleted = false;
		protected Hashtable hashInfos;
		protected string strIp;
		protected bool blnSaveLog;
		protected int intPriority;
		protected string attName;
		protected string attValue;

		public Tests(string name,int testId,int programId,int requirement,Hashtable infos,string ip,bool saveLog,int priority,int highscore)
		{
			strName = name;
			intTestId = testId;
			intProgramId = programId;
			intRequirement = requirement;
			hashInfos = infos;
			strIp = ip;
			blnSaveLog = saveLog;
			intHighScore = highscore;
			intPriority = priority;
			attName = getAttName();
		}

		private string getAttName(){
			string tmpStr = "";

			if(HashInfos.ContainsKey(15)){
				tmpStr = HashInfos[15].ToString();
			}

			return tmpStr;
		}

		public DateTime DatStarttime
		{
			get
			{
				return datStarttime;
			}
			set
			{
				datStarttime = value;
			}
		}

		public string StrName
		{
			get
			{
				return strName;
			}
		}

		public string StrIp
		{
			get
			{
				return strIp;
			}
		}

		public int IntTestId
		{
			get
			{
				return intTestId;
			}
		}

		public int IntScore
		{
			get
			{
				return intScore;
			}
			set
			{
				intScore = value;
			}
		}

		public int IntHighScore
		{
			get
			{
				return intHighScore;
			}
			set
			{
				intHighScore = value;
			}
		}

		public double DblSeconds
		{
			get
			{
				return dblSeconds;
			}
			set
			{
				dblSeconds = value;
			}
		}

		public int IntProgramId
		{
			get
			{
				return intProgramId;
			}
		}

		public int IntRequirement
		{
			get
			{
				return intRequirement;
			}
		}

		public bool BlnCompleted
		{
			get
			{
				return blnCompleted;
			}
			set
			{
				blnCompleted = value;
			}
		}

		public bool BlnHighScore
		{
			get
			{
				return blnHighScore;
			}
			set
			{
				blnHighScore = value;
			}
		}

		public string AttValue
		{
			get
			{
				return attValue;
			}
			set
			{
				attValue = value;
			}
		}

		public string AttName
		{
			get
			{
				return attName;
			}
			set
			{
				attName = value;
			}
		}

		public bool BlnSaveLog
		{
			get
			{
				return blnSaveLog;
			}
		}

		public Hashtable HashInfos
		{
			get
			{
				return hashInfos;
			}
		}

		private void unlockNextLevel()
		{
			Database db = new Database();

			string strSql = "SELECT test_schedule_tests.id,testid,islocked "
				+ "FROM test_schedule_tests INNER JOIN tests ON testid = tests.id "
				+" INNER JOIN test_schedule ON scheduleid = test_schedule.id "
				+" WHERE test_schedule.id = " + intProgramId + " AND tests.priority > " + intPriority 
				+ " AND bbname LIKE '3-D%' AND islocked <> -1 ORDER BY priority LIMIT 0,1";

			MySqlDataReader objDr = db.select(strSql);
			
			if(objDr.Read())
			{
				if(Convert.ToInt32(objDr["islocked"]) == 0)
				{
					Database db_up = new Database();

					string strSql_up = "UPDATE test_schedule_tests SET islocked = 1 WHERE id = " + Convert.ToInt32(objDr["id"]);

					db_up.execSql(strSql_up);

					db_up = null;
				}
			}

			db.objDataReader.Close();
            db.dbDispose();
            objDr.Close();
			db = null;
		}
		
		public void saveLog()
		{
			string strSql = "";
			Tests testtesttest = (Tests)Session["tests"];

            if(((Tests)Session["tests"]).blnCompleted)
			{
				unlockNextLevel();
			}

			int intBlnHighscore = 0;
            Database db;
			if(((Tests)Session["tests"]).BlnHighScore){
				intBlnHighscore = 1;
                 db = new Database();
				strSql = "UPDATE log_testresult SET highscore = 0 WHERE clientid = " + ((User)Session["user"]).IntUserId + " AND testid = " + ((Tests)Session["tests"]).IntTestId;
				db.execSql(strSql);
                db.dbDispose();
				db = null;
			}

			db = new Database();

			strSql = "INSERT INTO log_testresult (addedtime,clientid,testid,programid,seconds,score,highscore,ip,attname,attvalue) VALUES('";
			strSql += datStarttime.ToString("yyyy-MM-dd HH:mm:ss") + "'," + ((User)Session["user"]).IntUserId + "," + ((Tests)Session["tests"]).IntTestId + "," + ((Tests)Session["tests"]).IntProgramId + "," + ((Tests)Session["tests"]).DblSeconds.ToString().Replace(",",".") + ",";
			strSql += ((Tests)Session["tests"]).IntScore + "," + intBlnHighscore + ",'" + ((Tests)Session["tests"]).StrIp + "','" + ((Tests)Session["tests"]).AttName + "','" + ((Tests)Session["tests"]).AttValue + "');";

			db.execSql(strSql);
            db.dbDispose();
			db = null;
		}
	}
}
